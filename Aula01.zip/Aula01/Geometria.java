import java.util.ArrayList;


public class Geometria
{
	public static void main(String[] args)
	{
		ArrayList<Figuras> figuras = new ArrayList<Figuras>();
		ArrayList<Figuras3D> figuras3D = new ArrayList<Figuras3D>();
	
		figuras.add(new Triangulo (5,7));
		figuras.add(new Circulo(6));
		figuras.add(new Losango(6,12));
		figuras.add(new Retangulo(10,11));
		figuras.add(new Quadrado(5,7));
		figuras.add(new Trapezio(8,10,9));
		
		figuras3D.add(new Cubo(10,10));
		figuras3D.add(new Cilindro(10,9));
		figuras3D.add(new Esfera(10,5));
		figuras3D.add(new Piramide(6,6));
		
		for(int i = 0; i < figuras.size(); i++)
		{
			System.out.println(figuras.get(i).toString());
		}
		
		for(int i = 0; i < figuras3D.size(); i++)
		{
			System.out.println(figuras3D.get(i).toString());
		}
	}
}